package DansaGUI;
import DansaBackEnd.Dancer;
import DansaBackEnd.DansaDB;
import DansaBackEnd.FileIO;
import DansaBackEnd.HeapSort;
import DansaBackEnd.PrintUtilities;
import DansaBackEnd.Validation;
import java.io.FileNotFoundException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultListModel;
/**
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~<br>
 * Class    CafeDansaDriver<br>
 * File     CafeDansaDriver.Java<br>
 * Description      Driver class for the Cafe Dansa Database prject<br>
 *<br>
 * @author Nasser Najib <br>
 * Environment PC, Windows 10, jdk1.8, NetBeans 8.2 Date<br>
 * @version 1.0<br>
 */
public class CafeDansaDriver {
    //class level variables
    static DansaDB db = new DansaDB();
    static ArrayList<Dancer> dancers = new ArrayList<>();
    static CafeDansaGUI gui = new CafeDansaGUI();
    static DefaultListModel memberList;
    
    public static void main(String[] args){
        //load databases upon launch
        loadDB();
        
        memberList = gui.getListModel();
        updateMemberList();
        gui.display();
    }
    /** <pre>
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~<br>
     * Method Name      addDancer<br>
     * @author          Nasser Najib<br>
     * Description      calls the database class to add a member to the table<br>
     * @param dancer<br>
     * @return          int - signifying success<br>
     * History Log:     05/15/19 - creation<br>
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * </pre>
     */
    public static int addDancer(Dancer dancer){
        int ret = db.addDancer(dancer);
        if(ret != 0){
            //ErrorMessage
            System.out.println(ret);
        }
        else{
            dancers.add(dancer);
            updateMemberList();
        }
        return ret;
    }
    /** <pre>
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~<br>
     * Method Name      loadDB<br>
     * @author          Nasser Najib<br>
     * Description      Loads database into an arrayList, backend does the mining<br>
     * History Log:     05/15/19 - creation<br>
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * </pre>
     */
    public static void loadDB(){
        
        try{
            dancers = db.getDancers();
        }
        catch(ClassNotFoundException | SQLException e){
        }
    }
    /** <pre>
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~<br>
     * Method Name      updateMemberList<br>
     * @author          Nasser Najib<br>
     * Description      updates the list box model so that the most current list<br>
     *                  is displayed.<br>
     * History Log:     05/15/19 - creation<br>
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * </pre>
     */
    private static void updateMemberList(){
        memberList.removeAllElements();
        HeapSort<Dancer> sort = new HeapSort<>(dancers);
        sort.sort();
        for(int i = 0; i < dancers.size(); i++){
            Dancer d = dancers.get(i);
            memberList.addElement(d.getFirstName() + " " + d.getLastName() + " ("
            + d.getYears() + " years)");
        }
    }
    /** <pre>
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~<br>
     * Method Name      changeCompareMode<br>
     * @author          Nasser Najib<br>
     * Description      changes which property Dancer's compareTo feature compares by<br>
     * History Log:<br>
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * </pre>
     */
    public static void changeCompareMode(int comp){
        for(int i = 0; i < dancers.size(); i++)
            dancers.get(i).setCompareMode(comp);
        updateMemberList();
    }
    /** <pre>
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * Method Name      loadFromFile
     * @author          Nasser Najib
     * Description      Reads dancer information from a text file and adds it to the database<br>
     * History Log:<br>
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~<br>
     * </pre>
     */
    public static void loadFromFile(){

        FileIO loader = new FileIO("Text File", "txt");
        
        try {
            Scanner scanner = new Scanner(loader.loadFile());
            String input = "";
            while(scanner.hasNext()){
                input = scanner.nextLine();
                Dancer dancer = parseInput(input);
                addDancer(dancer);
            }
        } 
        catch (FileNotFoundException ex){
        }
    }
    /** <pre>
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~<br>
     * Method Name      parseInput<br>
     * @args            input - input line to be parsed<br>
     * @author          Nasser Najib<br>
     * Description      Attemps to convert a comma-delimitted line into a dancer object<br>
     * @return          Dancer - a dancer loaded from a text file<br>
     * History Log:     05/15/19 - creation<br>
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * </pre>
     */
    private static Dancer parseInput(String input) {
        
        Dancer ret = new Dancer();
        StringTokenizer tokenizer = new StringTokenizer(input, ",");
        String first = "", last = "", danceStyle = "", proficiency = "", 
                phone = "", email = "";
        int years = 0, errorCount = 0;
        System.out.println(input);
        while(tokenizer.hasMoreTokens()){
            try{
                System.out.println(input);
                first = tokenizer.nextToken();
                last = tokenizer.nextToken();
                danceStyle = tokenizer.nextToken();
                proficiency = tokenizer.nextToken();
                years = Integer.parseInt(tokenizer.nextToken());
                phone = tokenizer.nextToken();
                email = tokenizer.nextToken();
            }
            catch(Exception e){
                errorCount++;
                System.out.println("Error in file format!");
            }
        }
        if(isValid(first, last, danceStyle, proficiency, String.valueOf(years), phone, email))
            ret = new Dancer(first, last, danceStyle, proficiency, years, phone, email);
        return ret;
    }
    /** <pre>
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~<br>
     * Method Name      isValid<br>
     * @author          Nasser Najib<br>
     * Description      Check if the input inputs are valid and in the proper format<br>
     * @see Validation.Java<br>
     * History Log:     05/15/19 - creation<br>
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * </pre>
     */
    static boolean isValid(String first, String last, String danceStyle, String proficiency,
            String years, String phone, String email){
        boolean ret = false;
        Validation validator = new Validation();
        if(validator.isLettersOnly(first) && validator.isLettersOnly(last)
                && validator.isLettersOnly(danceStyle) && validator.isEmail(email)
                && validator.isLettersOnly(proficiency) && validator.isPhoneNumber(phone))
            ret = !ret;
        return ret;
    }
    /** <pre>
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~<br>
     * Method Name      getMember<br>
     * @author          Nasser Najib<br>
     * Description      accessor method, gives access to a Dancer object at a specified index<br>
     * History Log:     05/15/19 - creation<br>
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * </pre>
     */
    static Dancer getMember(int member) {
        return dancers.get(member);
    }
    /** <pre>
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~<br>
     * Method Name      updateDancer<br>
     * @author          Nasser Najib<br>
     * Description      attempts to update a dancers information in the database<br>
     * History Log:     05/15/19 - creation<br>
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * </pre>
     */
    static int updateDancer(Dancer original, Dancer updated){
        int ret = -1;
        try {
            ret = db.updateDancer(original, updated);
            dancers.remove(original);
            dancers.add(updated);
        }
        catch(Exception e){
            System.out.println("SQL ERROR");
        }
        if(ret == 0)
            updateMemberList();
    return ret;
    }
    /** <pre>
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~<br>
     * Method Name      deleteMember<br>
     * @author          Nasser Najib<br>
     * Description      removes a specified member from the database<br>
     * History Log:     05/15/19 - creation<br>
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * </pre>
     * @param d
     */
    public static void deleteMember(Dancer d) {
        dancers.remove(d);
        try {
            if(db.remove(d) == 0)
                updateMemberList();
            
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(CafeDansaDriver.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    /** <pre>
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~<br>
     * Method Name      clear<br>
     * @author          Nasser Najib<br>
     * Description      clears the database<br>
     * History Log:<br>
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * </pre>
     */
    static void clear() {
        try {
            db.clearDB();
            dancers.clear();
            updateMemberList();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(CafeDansaDriver.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    /** <pre>
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~<br>
     * Method Name      print<br>
     * @author          Nasser Najib<br>
     * Description      prints the specified components<br>
     * History Log:     05/15/19 - creation.<br>
     * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     * </pre>
     */
    static void print(CafeDansaGUI aThis) {
        PrintUtilities.printComponent(aThis);
    }
}
